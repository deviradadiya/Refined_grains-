import React from 'react'
import "./Header.css";
import Login from './Login';

const Header = () => {
  return (
    <div></div>

  )
}

export default Header